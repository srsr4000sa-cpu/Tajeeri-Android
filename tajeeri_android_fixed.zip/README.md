# تأجيري — Android Native

هذه نسخة Android Native فعلية مبنية من وظائف المشروع الحالي، وليست WebView ولا PWABuilder.

تشمل النسخة:
- شاشة التأجيرات
- إضافة تأجير
- حساب الرصيد
- تسديد/إرجاع
- شاشة المواد
- شاشة الديون
- قفل PIN
- واجهة عربية وRTL

## بناء APK
يتطلب Android Studio أو Gradle مع Android SDK.
من مجلد المشروع:
`./gradlew assembleDebug`

الناتج:
`app/build/outputs/apk/debug/app-debug.apk`

## ملاحظة
البيانات في هذه النسخة محفوظة داخل حالة التطبيق المحلية كبداية. المرحلة التالية للإنتاج هي ربط التخزين الدائم (DataStore/Room) وإضافة النسخ الاحتياطي، ثم توقيع release وإخراج AAB.
