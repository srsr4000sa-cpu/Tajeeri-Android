package com.tajeeri.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewmodel.compose.viewModel
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.*

@Serializable data class Payment(val id: String, val amount: Double, val date: String)
@Serializable data class Rental(
    val id: String, val customerName: String, val itemName: String,
    val unitDailyPrice: Double, val quantity: Int, val startDate: String,
    val phone: String = "", val address: String = "", val note: String = "",
    val returnedAt: String? = null, val payments: List<Payment> = emptyList()
)
@Serializable data class Material(val id: String, val name: String, val price: Double)
@Serializable data class Settings(val shopName: String = "تأجيري", val pinEnabled: Boolean = false, val pin: String? = null)
@Serializable data class Database(val rentals: List<Rental> = emptyList(), val materials: List<Material> = emptyList(), val settings: Settings = Settings())

class TajeeriViewModel : ViewModel() {
    var db by mutableStateOf(Database())
        private set

    private val currency = NumberFormat.getIntegerInstance(Locale("ar","IQ"))

    fun money(v: Double) = "${currency.format(v)} د.ع"

    fun addMaterial(name: String, price: Double) {
        db = db.copy(materials = listOf(Material(UUID.randomUUID().toString(), name, price)) + db.materials)
    }
    fun deleteMaterial(id: String) {
        db = db.copy(materials = db.materials.filterNot { it.id == id })
    }
    fun addRental(customer: String, item: String, price: Double, qty: Int, phone: String) {
        db = db.copy(rentals = listOf(
            Rental(UUID.randomUUID().toString(), customer, item, price, qty,
                SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date()), phone = phone)
        ) + db.rentals)
    }
    fun addPayment(id: String, amount: Double) {
        db = db.copy(rentals = db.rentals.map {
            if (it.id == id) it.copy(payments = it.payments + Payment(UUID.randomUUID().toString(), amount, Date().toString()))
            else it
        })
    }
    fun returnRental(id: String) {
        db = db.copy(rentals = db.rentals.map { if (it.id == id) it.copy(returnedAt = Date().toString()) else it })
    }
    fun balance(r: Rental): Double {
        val days = maxOf(1, ((System.currentTimeMillis() - parseDate(r.startDate)) / 86400000L).toInt() + 1)
        val total = days * r.unitDailyPrice * r.quantity
        return maxOf(0.0, total - r.payments.sumOf { it.amount })
    }
    fun updateSettings(pinEnabled: Boolean, pin: String?) {
        db = db.copy(
            settings = db.settings.copy(
                pinEnabled = pinEnabled,
                pin = if (pinEnabled) pin else null
            )
        )
    }

    private fun parseDate(s: String): Long = try {
        SimpleDateFormat("yyyy-MM-dd", Locale.US).parse(s)?.time ?: System.currentTimeMillis()
    } catch (_: Exception) { System.currentTimeMillis() }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { TajeeriApp() }
    }
}

@Composable
fun TajeeriApp(vm: TajeeriViewModel = viewModel()) {
    var tab by remember { mutableIntStateOf(0) }
    var pinUnlocked by remember { mutableStateOf(false) }

    if (vm.db.settings.pinEnabled && !pinUnlocked) {
        PinScreen(
            onUnlock = { if (it == vm.db.settings.pin) pinUnlocked = true }
        )
        return
    }

    MaterialTheme {
        Scaffold(
            bottomBar = {
                NavigationBar {
                    listOf(
                        "التأجيرات" to Icons.Default.CalendarMonth,
                        "المواد" to Icons.Default.Inventory2,
                        "الديون" to Icons.Default.AccountBalanceWallet,
                        "الإعدادات" to Icons.Default.Settings
                    ).forEachIndexed { i, item ->
                        NavigationBarItem(
                            selected = tab == i,
                            onClick = { tab = i },
                            icon = { Icon(item.second, null) },
                            label = { Text(item.first) }
                        )
                    }
                }
            }
        ) { pad ->
            Box(Modifier.padding(pad).fillMaxSize()) {
                when (tab) {
                    0 -> RentalsScreen(vm)
                    1 -> MaterialsScreen(vm)
                    2 -> DebtsScreen(vm)
                    else -> SettingsScreen(vm)
                }
            }
        }
    }
}

@Composable
fun PinScreen(onUnlock: (String) -> Unit) {
    var pin by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        Icon(Icons.Default.Lock, null, modifier = Modifier.size(56.dp))
        Spacer(Modifier.height(16.dp))
        Text("أدخل رمز الحماية", style = MaterialTheme.typography.headlineSmall)
        Spacer(Modifier.height(16.dp))
        OutlinedTextField(
            value = pin, onValueChange = { if (it.length <= 4) pin = it },
            label = { Text("الرمز") }, visualTransformation = PasswordVisualTransformation()
        )
        Spacer(Modifier.height(12.dp))
        Button(onClick = { onUnlock(pin) }, enabled = pin.length == 4) { Text("دخول") }
    }
}

@Composable
fun RentalsScreen(vm: TajeeriViewModel) {
    var show by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("التأجيرات", style = MaterialTheme.typography.headlineMedium)
        Spacer(Modifier.height(12.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.weight(1f)) {
            items(vm.db.rentals) { r ->
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp)) {
                        Text(r.customerName, style = MaterialTheme.typography.titleMedium)
                        Text("${r.itemName} • ${r.unitDailyPrice} د.ع/يوم • كمية ${r.quantity}")
                        Text("المتبقي: ${vm.money(vm.balance(r))}", color = MaterialTheme.colorScheme.primary)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            if (r.returnedAt == null) Button(onClick = { vm.returnRental(r.id) }) { Text("إرجاع") }
                            OutlinedButton(onClick = { vm.addPayment(r.id, vm.balance(r)) }, enabled = vm.balance(r) > 0) { Text("تسديد") }
                        }
                    }
                }
            }
        }
        Button(onClick = { show = true }, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.Add, null); Spacer(Modifier.width(6.dp)); Text("إضافة تأجير") }
    }
    if (show) AddRentalDialog(vm) { show = false }
}

@Composable
fun AddRentalDialog(vm: TajeeriViewModel, close: () -> Unit) {
    var customer by remember { mutableStateOf("") }
    var item by remember { mutableStateOf("") }
    var price by remember { mutableStateOf("") }
    var qty by remember { mutableStateOf("1") }
    var phone by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = close,
        title = { Text("إضافة تأجير") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(customer, { customer = it }, label = { Text("اسم الزبون") })
                OutlinedTextField(item, { item = it }, label = { Text("المادة") })
                OutlinedTextField(price, { price = it }, label = { Text("السعر اليومي") })
                OutlinedTextField(qty, { qty = it }, label = { Text("الكمية") })
                OutlinedTextField(phone, { phone = it }, label = { Text("الهاتف") })
            }
        },
        confirmButton = {
            Button(onClick = {
                if (customer.isNotBlank() && item.isNotBlank()) {
                    vm.addRental(customer, item, price.toDoubleOrNull() ?: 0.0, qty.toIntOrNull() ?: 1, phone)
                    close()
                }
            }) { Text("إضافة") }
        },
        dismissButton = { TextButton(onClick = close) { Text("إلغاء") } }
    )
}

@Composable
fun MaterialsScreen(vm: TajeeriViewModel) {
    var show by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("المواد", style = MaterialTheme.typography.headlineMedium)
        Spacer(Modifier.height(12.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.weight(1f)) {
            items(vm.db.materials) { m ->
                Card(Modifier.fillMaxWidth()) {
                    Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Inventory2, null)
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) { Text(m.name); Text("${m.price} د.ع / يوم") }
                        IconButton(onClick = { vm.deleteMaterial(m.id) }) { Icon(Icons.Default.Delete, null) }
                    }
                }
            }
        }
        Button(onClick = { show = true }, modifier = Modifier.fillMaxWidth()) { Text("إضافة مادة") }
    }
    if (show) {
        var name by remember { mutableStateOf("") }
        var price by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { show = false },
            title = { Text("إضافة مادة") },
            text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(name, { name = it }, label = { Text("اسم المادة") })
                OutlinedTextField(price, { price = it }, label = { Text("السعر اليومي") })
            }},
            confirmButton = { Button(onClick = { if (name.isNotBlank()) { vm.addMaterial(name, price.toDoubleOrNull() ?: 0.0); show = false } }) { Text("إضافة") } },
            dismissButton = { TextButton(onClick = { show = false }) { Text("إلغاء") } }
        )
    }
}

@Composable
fun DebtsScreen(vm: TajeeriViewModel) {
    val debts = vm.db.rentals.map { it to vm.balance(it) }.filter { it.second > 0 }
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("الديون", style = MaterialTheme.typography.headlineMedium)
        Spacer(Modifier.height(12.dp))
        Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(16.dp)) {
            Text("إجمالي الديون")
            Text(vm.money(debts.sumOf { it.second }), style = MaterialTheme.typography.headlineSmall, color = MaterialTheme.colorScheme.primary)
        }}
        Spacer(Modifier.height(12.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(debts) { (r,b) ->
                Card(Modifier.fillMaxWidth()) { Row(Modifier.padding(16.dp)) {
                    Column(Modifier.weight(1f)) { Text(r.customerName); Text(r.itemName) }
                    Text(vm.money(b))
                }}
            }
        }
    }
}

@Composable
fun SettingsScreen(vm: TajeeriViewModel) {
    var pinEnabled by remember { mutableStateOf(vm.db.settings.pinEnabled) }
    var pin by remember { mutableStateOf(vm.db.settings.pin ?: "") }
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("الإعدادات", style = MaterialTheme.typography.headlineMedium)
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("قفل التطبيق", Modifier.weight(1f))
            Switch(checked = pinEnabled, onCheckedChange = { pinEnabled = it })
        }
        OutlinedTextField(pin, { if (it.length <= 4) pin = it }, label = { Text("رمز PIN من 4 أرقام") })
        Button(onClick = {
            vm.updateSettings(pinEnabled, pin)
        }) { Text("حفظ") }
    }
}
